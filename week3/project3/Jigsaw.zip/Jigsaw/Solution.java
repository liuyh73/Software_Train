package solution;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import jigsaw.Jigsaw;
import jigsaw.JigsawNode;


public class Solution extends Jigsaw {

    private int searchedNodesNum;           

    private Queue<JigsawNode> exploreList;  
    private Set<JigsawNode> visitedList;   

    public Solution() {
    	this.searchedNodesNum=0;
    	this.exploreList=null;
    	this.visitedList=null;
    }

    public Solution(JigsawNode bNode, JigsawNode eNode) {
        super(bNode, eNode);
    }


    public boolean BFSearch(JigsawNode bNode, JigsawNode eNode) {
    	this.visitedList=new HashSet<JigsawNode>(1000);
    	this.exploreList = new LinkedList<JigsawNode>();
    	this.beginJNode = new JigsawNode(bNode);
        this.endJNode = new JigsawNode(eNode);
        this.currentJNode = null;

        final int MAX_NODE_NUM = 29000;
        final int DIRS = 4;


        this.searchedNodesNum = 0;

        this.visitedList.add(this.beginJNode);
        this.exploreList.add(this.beginJNode);

        while (this.searchedNodesNum < MAX_NODE_NUM && !this.exploreList.isEmpty()) {
            this.searchedNodesNum++;

            this.currentJNode = this.exploreList.poll();
            if (this.currentJNode.equals(eNode)) {
                this.getPath();
                break;
            }

            JigsawNode[] nextNodes = new JigsawNode[]{
                new JigsawNode(this.currentJNode), new JigsawNode(this.currentJNode),
                new JigsawNode(this.currentJNode), new JigsawNode(this.currentJNode)
            };

            for (int i = 0; i < DIRS; i++) {
                if (nextNodes[i].move(i) && !this.visitedList.contains(nextNodes[i])) {
                    this.visitedList.add(nextNodes[i]);
                    this.exploreList.add(nextNodes[i]);
                }
            }
        }
        System.out.println("Jigsaw BFS Search Result:");
        System.out.println("Begin state:" + this.getBeginJNode().toString());
        System.out.println("End state:" + this.getEndJNode().toString());
        // System.out.println("Solution Path: ");
        // System.out.println(this.getSolutionPath());
        System.out.println("Total number of searched nodes:" + this.searchedNodesNum);
        System.out.println("Depth of the current node is:" + this.getCurrentJNode().getNodeDepth());
        
        return this.isCompleted();
    }

    public void estimateValue(JigsawNode jNode) {
        int s = 0; 
        int dimension = JigsawNode.getDimension();
        double manhatten=0, geometric=0;
        for (int index = 1; index < dimension * dimension; index++) {
            if (jNode.getNodesState()[index] + 1 != jNode.getNodesState()[index + 1]) {
                s++;
            }
        }
        
        for(int i=1;i<jNode.getNodesState().length;i++) {
        	int curR=(i-1)/dimension+1;
        	int curC=i%dimension==0 ? dimension : i%dimension;
        	int desR=(jNode.getNodesState()[i]-1)/dimension+1;
        	int desC=jNode.getNodesState()[i]%dimension==0 ? dimension : jNode.getNodesState()[i]%dimension;
        	double dR=Math.abs(curR-desR);
        	double dC=Math.abs(curC-desC);
        	manhatten+=dR+dC;
        	geometric+=Math.sqrt(dR*dR+dC*dC);
        }
        s=(int)((s+manhatten+geometric));
        jNode.setEstimatedValue(s);
    }
}
