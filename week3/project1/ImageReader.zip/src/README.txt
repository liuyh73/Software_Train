﻿文件目录为：
ImageReader(工程文件夹)
        |
        |——src(源文件)
        |	    |
        |	    |——ImageProcessorTest.java
        |	    |——ImageReaderRunner.java
        |	    |——ImplementImageIO.java
        |	    |——ImplementImageProcessor.java
        |
        |——bmptest(图片所在文件夹)


使用Eclipse建立工程目录ImageReader，并建立相应的java文件，否则可能导致读取图片路径不正确而引起错误。

